CMAKE_ANDROID_GUI
-----------------

.. versionadded:: 3.1

Default value for the :prop_tgt:`ANDROID_GUI` target property of
executables.  See that target property for additional information.
