CMAKE_BUILD_TOOL
----------------

This variable exists only for backwards compatibility.
It contains the same value as :variable:`CMAKE_MAKE_PROGRAM`.
Use that variable instead.
