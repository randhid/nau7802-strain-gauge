CMAKE_MINIMUM_REQUIRED_VERSION
------------------------------

The ``<min>`` version of CMake given to the most recent call to the
:command:`cmake_minimum_required(VERSION)` command in the current
variable scope or any parent variable scope.
