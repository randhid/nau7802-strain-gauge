CMAKE_CTEST_COMMAND
-------------------

Full path to :manual:`ctest(1)` command installed with CMake.

This is the full path to the CTest executable :manual:`ctest(1)` which is
useful from custom commands that want to use the :manual:`cmake(1)` ``-E``
option for portable system commands.
