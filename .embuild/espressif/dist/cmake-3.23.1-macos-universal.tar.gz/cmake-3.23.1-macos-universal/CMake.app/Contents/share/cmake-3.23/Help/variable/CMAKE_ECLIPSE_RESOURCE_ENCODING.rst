CMAKE_ECLIPSE_RESOURCE_ENCODING
-------------------------------

.. versionadded:: 3.16

This cache variable tells the :generator:`Eclipse CDT4` project generator
to set the resource encoding to the given value in generated project files.
If no value is given, no encoding will be set.
